﻿using C5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Services
{
    internal class DatabaseServices
    {
    }
}
