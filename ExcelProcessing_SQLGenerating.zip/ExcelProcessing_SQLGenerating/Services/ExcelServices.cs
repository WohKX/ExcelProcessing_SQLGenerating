﻿using C5;
using ExcelProcessing_SQLGenerating.Model;
using OfficeOpenXml;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Services
{
    public static class ExcelServices
    {
        public static int GetLastUsedRow(ExcelWorksheet sheet)
        {
            var row = sheet.Dimension.End.Row;
            while (row >= 1)
            {
                var range = sheet.Cells[row, 1, row, sheet.Dimension.End.Column];
                if (range.Any(c => !string.IsNullOrEmpty(c.Text)))
                {
                    break;
                }
                row--;
            }
            return row;
        }

        public static int GetLastUsedColumn(ExcelWorksheet sheet)
        {
            var column = sheet.Dimension.End.Column;
            while (column >= 1)
            {
                var range = sheet.Cells[1, column, sheet.Dimension.End.Row, column];
                if (range.Any(r => !string.IsNullOrEmpty(r.Text)))
                {
                    break;
                }
                column--;
            }
            return column;
        }

        /// <summary>
        /// Validate No Empty Cell within the range of sheet Dimension
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="processingWorkSheet"></param>
        /// <returns></returns>
        public static bool ValidateNoEmptyCell(ExcelWorksheet sheet, ExcelSheetObject processingWorkSheet)
        {
            bool noEmptyFlag = true;

            try
            {
                for (int checkingRow = sheet.Dimension.Start.Row; checkingRow <= processingWorkSheet.LastRowNum; checkingRow++)
                {
                    for (int checkingColumn = sheet.Dimension.Start.Column; checkingColumn <= processingWorkSheet.LastColNum; checkingColumn++)
                    {
                        string mergeRange = GetMergedRangeAddress(sheet.Cells[checkingRow, checkingColumn]);
                        int cellStartRow = mergeRange == null ? checkingRow : sheet.Cells[mergeRange].Start.Row; // 1st row of the merged cell
                        int cellStartCol = mergeRange == null ? checkingColumn : sheet.Cells[mergeRange].Start.Column; // 1st col of merged cell
                        int cellEndRow = mergeRange == null ? checkingRow : sheet.Cells[mergeRange].End.Row; // last row of merged cell
                        int cellEndCol = mergeRange == null ? checkingColumn : sheet.Cells[mergeRange].End.Column; // last col of merged cell

                        if (sheet.Cells[cellStartRow, cellStartCol, cellEndRow, cellEndCol].Value == null)
                            noEmptyFlag = false;

                        if (!noEmptyFlag) break;
                    }
                    if (!noEmptyFlag) break;
                }
            }
            catch (Exception ex)
            {
                noEmptyFlag = false;
            }
            return noEmptyFlag;
        }

        /// <summary>
        /// Get All the Info of the Cell
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="cellChecking"></param>
        /// <returns>CellStartRow, CellStartCol, CellEndRow, CellEndCol, CellValue, CellAddress, ValueList</returns>
        /// 
        public static ExcelCellObject GetCellInfo(ExcelWorksheet sheet, ExcelCellObject cellChecking)
        {
            try
            {
                int cellRow = cellChecking.RowToCheck;
                int cellCol = cellChecking.ColToCheck;

                string mergeRange = GetMergedRangeAddress(sheet.Cells[cellRow, cellCol]);
                int cellStartRow = mergeRange == null ? cellRow : sheet.Cells[mergeRange].Start.Row; // 1st row of the merged cell
                int cellStartCol = mergeRange == null ? cellCol : sheet.Cells[mergeRange].Start.Column; // 1st col of merged cell
                int cellEndRow = mergeRange == null ? cellRow : sheet.Cells[mergeRange].End.Row; // last row of merged cell
                int cellEndCol = mergeRange == null ? cellCol : sheet.Cells[mergeRange].End.Column; // last col of merged cell

                //add into range if value is empty and not reach last col
                if (!cellChecking.RowToStop.Equals(-1))
                {
                    var valueBelow = sheet.Cells[cellEndRow + 1, cellStartCol, cellEndRow + 1, cellEndCol].Value;
                    while ((valueBelow == null || string.IsNullOrEmpty(valueBelow.ToString())) && cellEndRow < cellChecking.RowToStop)
                    {
                        cellEndRow++;
                        valueBelow = sheet.Cells[cellEndRow + 1, cellStartCol, cellEndRow + 1, cellEndCol].Value;
                    }
                }
                if (!cellChecking.ColToStop.Equals(-1))
                {
                    var valueBeside = sheet.Cells[cellStartRow, cellEndCol + 1, cellEndRow, cellEndCol + 1].Value;
                    while ((valueBeside == null || string.IsNullOrEmpty(valueBeside.ToString())) && cellEndCol < cellChecking.ColToStop)
                    {
                        cellEndCol++;
                        valueBeside = sheet.Cells[cellStartRow, cellEndCol + 1, cellEndRow, cellEndCol + 1].Value;
                    }
                }

                // re-do merging of columns
                string cellValue = sheet.Cells[cellStartRow, cellStartCol].GetValue<string>();
                sheet.Cells[cellStartRow, cellStartCol, cellEndRow, cellEndCol].Merge = true;
                sheet.Cells[cellStartRow, cellStartCol, cellEndRow, cellEndCol].Value = cellValue;

                System.Collections.Generic.List<string> valueList = cellValue.Split("\n").ToList();
                LinkedList<string> valueLinkedList = new();
                foreach (string s in valueList) valueLinkedList.InsertLast(s);

                return new ExcelCellObject()
                {
                    Return_Type = Constants.SUCCESS_TYPE,
                    CellStartRow = cellStartRow,
                    CellStartCol = cellStartCol,
                    CellEndRow = cellEndRow,
                    CellEndCol = cellEndCol,
                    CellValue = cellValue,
                    CellAddress = new ExcelAddress(cellStartRow, cellStartCol, cellEndRow, cellEndCol).Address,
                    ValueList = valueLinkedList,
                };
            }
            catch (Exception ex)
            {
                return new ExcelCellObject()
                {
                    Return_Type = Constants.ERROR_TYPE,
                    Return_Message = string.Concat("Cell info for [Row]: ", cellChecking.RowToCheck.ToString(), " [Col]:", cellChecking.ColToCheck.ToString()),
                };

            }
        }

        /// <summary>
        /// Get main key (upper left cell)
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="processingWorkSheet"></param>
        /// <returns>ColAddressList, ColNameList, MainKeyAddress, MainKeyValue</returns>
        public static ExcelSheetObject GetSheetKey(ExcelWorksheet sheet, ExcelSheetObject processingWorkSheet)
        {
            try
            {
                object locker = new();

                ExcelCellObject SheetMainKey = GetCellInfo(sheet, new ExcelCellObject()
                {
                    RowToCheck = sheet.Dimension.Start.Row,
                    ColToCheck = sheet.Dimension.Start.Column,
                    RowToStop = processingWorkSheet.LastRowNum,
                    ColToStop = processingWorkSheet.LastColNum,
                });

                if (SheetMainKey.Return_Type != Constants.SUCCESS_TYPE)
                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = "Error while getting sheet main key.",
                    };

                if (string.IsNullOrEmpty(SheetMainKey.CellValue) || string.IsNullOrEmpty(SheetMainKey.CellAddress))
                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = "Error while getting sheet main key value.",
                    };

                C5.LinkedList<string> ColAddress = new();
                C5.LinkedList<string> ColName = new();

                lock (locker)
                {
                    ColAddress.InsertLast(SheetMainKey.CellAddress); // [Address]
                    ColName.InsertLast(SheetMainKey.CellValue); // [ColName]
                }

                return new ExcelSheetObject()
                {
                    Return_Type = Constants.SUCCESS_TYPE,
                    ColAddressList = ColAddress,
                    ColNameList = ColName,
                    MainKeyAddress = SheetMainKey.CellAddress,
                    MainKeyValue = SheetMainKey.CellValue,
                };
            }
            catch (Exception ex)
            {
                return new ExcelSheetObject()
                {
                    Return_Type = Constants.ERROR_TYPE,
                    Return_Message = "Error while getting sheet main key.",
                };

            }
        }

        /// <summary>
        /// Get All Table Col (1st row in sheet)
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="processingWorkSheet"></param>
        /// <returns>ColAddressList, ColNameList</returns>
        public static ExcelSheetObject GetSheetTableCol(ExcelWorksheet sheet, ExcelSheetObject processingWorkSheet)
        {
            try
            {
                int colProcessing = sheet.Cells[new ExcelAddress(processingWorkSheet.MainKeyAddress).Address].End.Column; // initialize as last col of sheet main key cell
                int tableColLastRow = sheet.Cells[new ExcelAddress(processingWorkSheet.MainKeyAddress).Address].End.Row; // last col of sheet main key cell

                object locker = new();

                C5.LinkedList<string> ColAddress = processingWorkSheet.ColAddressList ?? new();
                C5.LinkedList<string> ColName = processingWorkSheet.ColNameList ?? new();

                while (colProcessing < processingWorkSheet.LastColNum)
                {
                    ExcelCellObject TableCol = GetCellInfo(sheet, new ExcelCellObject()
                    {
                        RowToCheck = sheet.Dimension.Start.Row,
                        ColToCheck = colProcessing + 1,
                        RowToStop = tableColLastRow,
                        ColToStop = processingWorkSheet.LastColNum,
                    });

                    if (TableCol.Return_Type != Constants.SUCCESS_TYPE)
                        return new ExcelSheetObject()
                        {
                            Return_Type = Constants.ERROR_TYPE,
                            Return_Message = string.Concat("Sheetname: ", sheet.Name, TableCol.Return_Message),
                        };

                    if (!string.IsNullOrEmpty(TableCol.CellValue))
                    {
                        lock (locker)
                        {
                            ColAddress.InsertLast(TableCol.CellAddress); // [Address]
                            ColName.InsertLast(TableCol.CellValue); // [ColName]
                        }
                    }

                    colProcessing = TableCol.CellEndCol;
                }

                return new ExcelSheetObject()
                {
                    Return_Type = Constants.SUCCESS_TYPE,
                    ColAddressList = ColAddress,
                    ColNameList = ColName,
                };
            }
            catch (Exception ex)
            {
                return new ExcelSheetObject()
                {
                    Return_Type = Constants.ERROR_TYPE,
                    Return_Message = "Error while processing column name data.",
                };  // In case of a blank sheet

            }

        }

        /// <summary>
        /// Get Column List to be Proccessed
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="processingWorkSheet"></param>
        /// <param name="processingColIndex"></param>
        /// <returns>ProcessingColAddressList</returns>
        public static ExcelSheetObject GetProcessingColAddresses(ExcelWorksheet sheet, ExcelSheetObject processingWorkSheet, int processingColIndex)
        {
            try
            {
                int keyStartCol = sheet.Cells[new ExcelAddress(processingWorkSheet.ColAddressList[processingColIndex]).Address].Start.Column; // 1st col of key cell
                int rowProcessing = sheet.Cells[new ExcelAddress(processingWorkSheet.ColAddressList[processingColIndex]).Address].End.Row; // initialize as last row of key cell
                object locker = new();

                C5.LinkedList<string> CellAddress = new();

                while (rowProcessing < processingWorkSheet.LastRowNum)
                {
                    ExcelCellObject TableKeyValue = GetCellInfo(sheet, new ExcelCellObject()
                    {
                        RowToCheck = rowProcessing + 1,
                        ColToCheck = keyStartCol,
                        RowToStop = processingWorkSheet.LastRowNum,
                    });

                    if (TableKeyValue.Return_Type != Constants.SUCCESS_TYPE)
                        return new ExcelSheetObject()
                        {
                            Return_Type = Constants.ERROR_TYPE,
                            Return_Message = string.Concat("Sheetname: ", sheet.Name, ", ", TableKeyValue.Return_Message),
                        };

                    if (!string.IsNullOrEmpty(TableKeyValue.CellValue))
                    {
                        lock (locker)
                        {
                            CellAddress.InsertLast(TableKeyValue.CellAddress); // [Address]
                        }
                    }

                    rowProcessing = TableKeyValue.CellEndRow;
                }


                return new ExcelSheetObject()
                {
                    Return_Type = Constants.SUCCESS_TYPE,
                    ProcessingColAddressList = CellAddress,
                };
            }
            catch (Exception ex)
            {
                return new ExcelSheetObject()
                {
                    Return_Type = Constants.ERROR_TYPE,
                    Return_Message = string.Concat("Sheetname: ", sheet.Name),
                };

            }
        }

        public static string GetMergedRangeAddress(this ExcelRange @this)
        {
            if (@this.Merge)
            {
                var idx = @this.Worksheet.GetMergeCellId(@this.Start.Row, @this.Start.Column);
                return @this.Worksheet.MergedCells[idx - 1]; //the array is 0-indexed but the mergeId is 1-indexed...
            }
            else
            {
                return @this.Address;
            }
        }
    }
}
