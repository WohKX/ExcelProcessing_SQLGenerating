﻿using ExcelProcessing_SQLGenerating.Controller;
using ExcelProcessing_SQLGenerating.Model;
using OfficeOpenXml;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExcelProcessing_SQLGenerating
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string ExcelFileNameText = "Please Select Excel File.";
        private const string TargetFileText = "Please Select File Destination.";

        public MainWindow()
        {
            InitializeComponent();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            ExcelFileNameTextBox.Text = ExcelFileNameText;
            TargetFileTextBox.Text = TargetFileText;
        }

        private void BrowseExcelButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
                // Set filter for file extension and default file extension  
                openFileDlg.DefaultExt = ".xlsx;";
                openFileDlg.Filter = "Excel documents (xlsx)|*.xlsx|Excel documents (xlx)|*.xlx";

                // Set initial directory    
                openFileDlg.InitialDirectory = @"C:\Temp\";


                // Launch OpenFileDialog by calling ShowDialog method
                Nullable<bool> result = openFileDlg.ShowDialog();
                // Get the selected file name and display in a TextBox.
                if (result == true)
                {
                    ExcelFileNameTextBox.Text = openFileDlg.FileName;
                }
                else
                {
                    ExcelFileNameTextBox.Text = ExcelFileNameText;
                }
            }
            catch (Exception ex)
            {
                string content = (string)WarningLabel.Content;
                if (!string.IsNullOrEmpty(content)) content += "&#10;";
                content += "Something wrong when loading Excel File.";
                WarningLabel.Content = content;

                ///write exception
            }

        }

        private void BrowseTargetFileButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var dialog = new System.Windows.Forms.FolderBrowserDialog())
                {
                    System.Windows.Forms.DialogResult result = dialog.ShowDialog();
                    if (result == System.Windows.Forms.DialogResult.OK)
                    {
                        TargetFileTextBox.Text = dialog.SelectedPath;
                    }
                    else
                    {
                        TargetFileTextBox.Text = TargetFileText;
                    }

                }
            }
            catch (Exception ex)
            {
                string content = (string)WarningLabel.Content;
                if (!string.IsNullOrEmpty(content)) content += "&#10;";
                content += "Something wrong when opening Targeting Folder.";
                WarningLabel.Content = content;

                ///write exception
            }

        }

        private void GenExcelButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                GenExcel();
            }
            catch (Exception ex)
            {
                WarningLabel.Content = ex.Message;
            }

        }

        private void GenExcel()
        {
            try
            {
                if (ExcelFileNameTextBox.Text == ExcelFileNameText) throw new Exception(ExcelFileNameText);
                if (TargetFileTextBox.Text == TargetFileText) throw new Exception(TargetFileText);

                string excelFilePath = ExcelFileNameTextBox.Text;
                string folderPath = TargetFileTextBox.Text;
                DateTime currentDateTime = DateTime.Now;

                ProcessExcelData.GenExcelWithCompleteRecord(new ExcelFileObject()
                {
                    FilePath = excelFilePath,
                    FolderPath = folderPath,
                    CreatedDateTime = currentDateTime,
                    CreatedDateTimeString = currentDateTime.ToString("yyyyMMdd_HHmmssffff"),
                });

            }
            catch (Exception ex)
            {


                ///write exception
            }
        }

        private void TestConnButton_Click(object sender, RoutedEventArgs e)
        {
            string connectionResponse = CheckGenSqlConnFields();
            if (!string.IsNullOrEmpty(connectionResponse))
            {
                ConnResultLabel.Content = connectionResponse;
            }
            else
            {

            }

        }



        private string CheckGenSqlConnFields()
        {
            string returnMsg = string.Empty;

            if(DatabaseSelection.SelectedValue == null || string.IsNullOrEmpty(DatabaseSelection.SelectedValue.ToString())) returnMsg += "DBMS cannot be empty. ";
            if(string.IsNullOrEmpty(DBServerTextBox.Text)) returnMsg += "Db server cannot be empty. ";
            if (string.IsNullOrEmpty(DBUserTextBox.Text)) returnMsg += "User ID cannot be empty. ";
            if (string.IsNullOrEmpty(DBPassTextBox.Text)) returnMsg += "User Password cannot be empty. ";
            if (string.IsNullOrEmpty(DBTableTextBox.Text)) returnMsg += "Table to be update cannot be empty. ";

            return returnMsg;
        }
    }


}
