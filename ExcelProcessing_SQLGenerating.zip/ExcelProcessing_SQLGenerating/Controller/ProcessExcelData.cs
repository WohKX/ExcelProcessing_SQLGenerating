﻿using C5;
using ExcelProcessing_SQLGenerating.Model;
using ExcelProcessing_SQLGenerating.Services;
using OfficeOpenXml;
using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Controller
{
    public static class ProcessExcelData
    {
        public static ExcelFileObject GenExcelWithCompleteRecord(ExcelFileObject excelFileObject)
        {
            try
            {
                string excelFilePath = excelFileObject.FilePath;
                string folderPath = string.Concat(excelFileObject.FolderPath, "\\", excelFileObject.CreatedDateTimeString);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                if(string.IsNullOrEmpty(excelFilePath))
                {
                    return new ExcelFileObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = "Excel File Path not valid.",
                    };
                }

                FileInfo selectedFile = new(excelFilePath);
                FileInfo tempFile = new(folderPath + "\\" + selectedFile.Name);
                excelFileObject.FileName = selectedFile.Name;

                using (ExcelPackage pck = new ExcelPackage(selectedFile))
                    pck.SaveAs(tempFile);

                using ExcelPackage tempPck = new(tempFile);
                ExcelSheetObject processingSheet = new();
                foreach (ExcelWorksheet ws in tempPck.Workbook.Worksheets)
                {
                    FileInfo resultFile = new(folderPath + "\\" + ws.Name + selectedFile.Extension);
                    using ExcelPackage resultPck = new(resultFile);
                    processingSheet = ProcessWorkSheet(resultPck, ws, excelFileObject);
                    if (processingSheet.Return_Type != Constants.SUCCESS_TYPE)
                    {
                        resultPck.Dispose();
                        //break;
                        return new ExcelFileObject()
                        {
                            Return_Type = Constants.ERROR_TYPE,
                            Return_Message = string.Concat("Error while proccessing worksheet:[", ws.Name, "], Details:[", processingSheet.Return_Message, "]"),
                        };
                    }
                    else
                    {
                        resultPck.Save();
                    }
                }
                tempPck.Dispose();
                if (processingSheet.Return_Type != Constants.SUCCESS_TYPE)
                    Directory.Delete(folderPath);// delete all created excel file if failed

                return new ExcelFileObject()
                {
                    Return_Type = Constants.SUCCESS_TYPE
                };
            }
            catch (Exception ex)
            {

                return new ExcelFileObject()
                {
                    Return_Type = Constants.ERROR_TYPE,
                    Return_Message = "Error while proccessing worksheet.",
                };
                ///write exception
            }
        }

        private static ExcelSheetObject ProcessWorkSheet(ExcelPackage excelPck, ExcelWorksheet sheet, ExcelFileObject excelFileObject)
        {
            try
            {
                if (sheet.Dimension == null)
                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = "Error while processing work sheet. (no sheet dimension found)",
                    };  // In case of a blank sheet

                object worksheetLock = new();

                #region Get Sheet Info
                #region Get Last Row and Column to be Processed
                int lastCellRow = ExcelServices.GetLastUsedRow(sheet);
                int lastCellCol = ExcelServices.GetLastUsedColumn(sheet);
                ExcelSheetObject realMainSheet = new()
                {
                    LastRowNum = lastCellRow,
                    LastColNum = lastCellCol,
                };
                #endregion

                #region Validate Sheet (Prevent empty cell in processing range)
                if (!ExcelServices.ValidateNoEmptyCell(sheet, realMainSheet))

                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = string.Concat("There is empty cell in the sheet [", sheet.Name, "]")
                    };
                #endregion

                #region Get Top Left Cell
                ExcelSheetObject sheetKeyObj = ExcelServices.GetSheetKey(sheet, realMainSheet);
                if (sheetKeyObj.Return_Type != Constants.SUCCESS_TYPE)
                {
                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = sheetKeyObj.Return_Message
                    };
                }

                lock (worksheetLock)
                {
                    realMainSheet.ColAddressList = sheetKeyObj.ColAddressList;
                    realMainSheet.ColNameList = sheetKeyObj.ColNameList;
                    realMainSheet.MainKeyAddress = sheetKeyObj.MainKeyAddress;
                    realMainSheet.MainKeyValue = sheetKeyObj.MainKeyValue;
                }
                #endregion

                #region Get All Table Column (1st Row of Sheet)
                ExcelSheetObject tableColObj = ExcelServices.GetSheetTableCol(sheet, realMainSheet);
                if (tableColObj.Return_Type != Constants.SUCCESS_TYPE)
                {
                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = tableColObj.Return_Message
                    };
                }

                lock (worksheetLock)
                {
                    realMainSheet.ColAddressList = tableColObj.ColAddressList;
                    realMainSheet.ColNameList = tableColObj.ColNameList;
                }
                #endregion
                #endregion

                #region Processing Sheet
                #region Split merge cells
                ExcelWorksheet splitMergeWs = excelPck.Workbook.Worksheets.Add(Constants.tempSheetName);
                // Copy Table Column
                for (int addressIndex = 0; addressIndex < realMainSheet.ColAddressList.Count; addressIndex++)
                {
                    string currentAddress = realMainSheet.ColAddressList[addressIndex];
                    string tempTableColVal = realMainSheet.ColNameList[addressIndex];
                    splitMergeWs.Cells[currentAddress].Merge = true;
                    splitMergeWs.Cells[currentAddress].Value = tempTableColVal;
                }

                for (int colIndex = 0; colIndex < realMainSheet.ColAddressList.Count; colIndex++)
                {
                    ExcelSheetObject splitingCol = ExcelServices.GetProcessingColAddresses(sheet, new ExcelSheetObject()
                    {
                        LastRowNum = ExcelServices.GetLastUsedRow(sheet),
                        ColAddressList = realMainSheet.ColAddressList,
                    }, colIndex);
                    if (splitingCol.Return_Type != Constants.SUCCESS_TYPE)
                    {
                        return new ExcelSheetObject()
                        {
                            Return_Type = Constants.ERROR_TYPE,
                            Return_Message = tableColObj.Return_Message,
                        };
                    }
                    foreach (string address in splitingCol.ProcessingColAddressList)
                    {
                        ExcelRange currentRowProcessingRange = sheet.Cells[address];
                        ExcelCellObject currentRowProcessingCell = ExcelServices.GetCellInfo(sheet, new ExcelCellObject()
                        {
                            RowToCheck = currentRowProcessingRange.Start.Row,
                            ColToCheck = currentRowProcessingRange.Start.Column,
                        });

                        splitMergeWs.Cells[currentRowProcessingCell.CellStartRow, currentRowProcessingCell.CellStartCol, currentRowProcessingCell.CellEndRow, currentRowProcessingCell.CellEndCol].Merge = false;

                        for (int processingRow = currentRowProcessingCell.CellStartRow; processingRow <= currentRowProcessingCell.CellEndRow; processingRow++)
                            splitMergeWs.Cells[processingRow, currentRowProcessingCell.CellStartCol].Value = currentRowProcessingCell.CellValue;
                    }

                }
                #endregion

                #region Loop All Column
                // initialize processing column = 1st column
                ExcelSheetObject tableProcessingCol = ExcelServices.GetProcessingColAddresses(splitMergeWs, new ExcelSheetObject()
                {
                    LastRowNum = ExcelServices.GetLastUsedRow(splitMergeWs),
                    ColAddressList = realMainSheet.ColAddressList,
                }, 0); // [Key Value Addresses]
                if (tableProcessingCol.Return_Type != Constants.SUCCESS_TYPE)
                {
                    return new ExcelSheetObject()
                    {
                        Return_Type = Constants.ERROR_TYPE,
                        Return_Message = tableColObj.Return_Message,
                    };
                };
                ExcelWorksheet previousWS = splitMergeWs;
                ExcelWorksheet currentWS;
                for (int colIndex = 0; colIndex < realMainSheet.ColAddressList.Count; colIndex++)
                {
                    #region Create New sheet for each Column
                    string sheetName = string.Concat(Constants.tempSheetName, "__", colIndex);
                    excelPck.Workbook.Worksheets.Add(sheetName);
                    currentWS = excelPck.Workbook.Worksheets[sheetName];
                    int notProccessedRow = currentWS.Cells[realMainSheet.MainKeyAddress].End.Row + 1;

                    // Copy Table Column
                    for (int addressIndex = 0; addressIndex < realMainSheet.ColAddressList.Count; addressIndex++)
                    {
                        string currentAddress = realMainSheet.ColAddressList[addressIndex];
                        string tempTableColVal = realMainSheet.ColNameList[addressIndex];
                        currentWS.Cells[currentAddress].Merge = true;
                        currentWS.Cells[currentAddress].Value = tempTableColVal;
                    }
                    #endregion

                    #region Split next line value of in cell 
                    foreach (string address in tableProcessingCol.ProcessingColAddressList)
                    {
                        ExcelRange currentRowProcessingRange = previousWS.Cells[address];
                        ExcelCellObject currentRowProcessingCell = ExcelServices.GetCellInfo(previousWS, new ExcelCellObject()
                        {
                            RowToCheck = currentRowProcessingRange.Start.Row,
                            ColToCheck = currentRowProcessingRange.Start.Column,
                        });

                        // split value into rows
                        foreach (string currentCellValue in currentRowProcessingCell.ValueList)
                        {
                            currentWS.Cells[notProccessedRow, currentRowProcessingRange.Start.Column].Value = currentCellValue;

                            int colToBeProccessed = previousWS.Cells[new ExcelAddress(realMainSheet.MainKeyAddress).Address].Start.Column; // initialize as 1st col of the row
                            #region Copy all cell before processing cell column
                            while (colToBeProccessed < currentRowProcessingCell.CellStartCol)
                            {
                                ExcelCellObject TableCol = new();


                                TableCol = ExcelServices.GetCellInfo(previousWS, new ExcelCellObject()
                                {
                                    RowToCheck = currentRowProcessingCell.CellStartRow,
                                    ColToCheck = colToBeProccessed,
                                    ColToStop = currentRowProcessingRange.Start.Column,
                                });

                                if (TableCol.Return_Type != Constants.SUCCESS_TYPE)
                                    return new ExcelSheetObject()
                                    {
                                        Return_Type = Constants.ERROR_TYPE,
                                        Return_Message = string.Concat("Sheetname: ", sheet.Name, TableCol.Return_Message),
                                    };

                                currentWS.Cells[notProccessedRow, TableCol.CellStartCol, notProccessedRow, TableCol.CellEndCol].Merge = true;
                                currentWS.Cells[notProccessedRow, TableCol.CellStartCol, notProccessedRow, TableCol.CellEndCol].Value = TableCol.CellValue;

                                colToBeProccessed = TableCol.CellEndCol + 1;
                            }
                            #endregion

                            colToBeProccessed = currentRowProcessingCell.CellEndCol + 1; // set as the column right after processing cell column 
                            #region Copy all cell after processing cell column
                            while (colToBeProccessed <= realMainSheet.LastColNum)
                            {
                                ExcelCellObject TableCol = new();
                                // loop all row in this column within processing cell column range
                                for (int currentProccessingRow = currentRowProcessingCell.CellStartRow; currentProccessingRow <= currentRowProcessingCell.CellEndRow; currentProccessingRow++)
                                {
                                    TableCol = ExcelServices.GetCellInfo(previousWS, new ExcelCellObject()
                                    {
                                        RowToCheck = currentProccessingRow,
                                        ColToCheck = colToBeProccessed,
                                        ColToStop = realMainSheet.LastColNum,
                                    });

                                    if (TableCol.Return_Type != Constants.SUCCESS_TYPE)
                                        return new ExcelSheetObject()
                                        {
                                            Return_Type = Constants.ERROR_TYPE,
                                            Return_Message = string.Concat("Sheetname: ", sheet.Name, TableCol.Return_Message),
                                        };

                                    currentWS.Cells[notProccessedRow, TableCol.CellStartCol, notProccessedRow, TableCol.CellEndCol].Merge = true;
                                    currentWS.Cells[notProccessedRow, TableCol.CellStartCol, notProccessedRow, TableCol.CellEndCol].Value = TableCol.CellValue;
                                }

                                colToBeProccessed = TableCol.CellEndCol + 1;
                            }
                            #endregion
                            notProccessedRow++;
                        }
                    }
                    #endregion

                    #region update sheet to new processing sheet
                    if (colIndex + 1 < realMainSheet.ColAddressList.Count)
                    {
                        previousWS = currentWS;
                        tableProcessingCol = ExcelServices.GetProcessingColAddresses(currentWS, new ExcelSheetObject()
                        {
                            LastRowNum = ExcelServices.GetLastUsedRow(currentWS),
                            ColAddressList = realMainSheet.ColAddressList,
                        }, colIndex + 1);
                        if (tableProcessingCol.Return_Type != Constants.SUCCESS_TYPE)
                        {
                            return new ExcelSheetObject()
                            {
                                Return_Type = Constants.ERROR_TYPE,
                                Return_Message = tableColObj.Return_Message,
                            };
                        }
                    }
                    else
                    {
                        excelPck.Workbook.Worksheets.Add(Constants.finalSheetName, currentWS);
                    }
                    #endregion
                }
                #endregion
                #endregion

                return new ExcelSheetObject() { Return_Type = Constants.SUCCESS_TYPE };
            }
            catch (Exception ex)
            {
                return new ExcelSheetObject()
                {
                    Return_Type = Constants.ERROR_TYPE,
                    Return_Message = string.Concat("Sheetname: ", sheet.Name),
                };
            }
        }
    }
}
