﻿using C5;

using System;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Model
{
    public class ExcelCellObject
    {
        public int RowToCheck { get; set; } = 0;
        public int ColToCheck { get; set; } = 0;
        public int RowToStop { get; set; } = -1;
        public int ColToStop { get; set; } = -1;
        




        public int CellStartRow { get; set; } = 0;
        public int CellStartCol { get; set; } = 0;
        public int CellEndRow { get; set; } = 0;
        public int CellEndCol { get; set; } = 0;

        public string CellValue { get; set; } = "";
        public string CellAddress { get; set; } = "";
        public LinkedList<string> ValueList { get; set; } = new();

        #region Return Obj
        public string Return_Type { get; set; } = Constants.PENDING_TYPE;
        public string? Return_Message { get; set; }
        #endregion
    }
}
