﻿using C5;
using System;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Model
{
    public class ExcelSheetObject
    {
        public int LastRowNum { get; set; } = 0;
        public int LastColNum { get; set; } = 0;

        public string? MainKeyAddress { get; set; } // Top Left Adrress of Cell in Sheet
        public string? MainKeyValue { get; set; }   // Top Left Value of Cell in Sheet
        public LinkedList<string> ColAddressList { get; set; } = new();  //  Addresses of 1st Row in Sheet
        public LinkedList<string> ColNameList { get; set; } = new(); //  Values of 1st Row in Sheet => Table Columns
        public LinkedList<string> ProcessingColAddressList { get; set; } = new(); // Addresses start from 1st record
        public string? ProccessingAddress { get; set; }
        public int ProcessingRow { get; set; } = 0;
        public int ProcessingCol { get; set; } = 0;

        #region Return Obj
        public string Return_Type { get; set; } = Constants.PENDING_TYPE;
        public string? Return_Message { get; set; }
        #endregion
    }
}
