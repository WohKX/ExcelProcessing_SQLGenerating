﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Model
{
    public class ExcelFileObject
    {
        public string? FilePath { get; set; }
        public string? FileName { get; set; }
        public string? FolderPath { get; set; }
        public string? CreatedDateTimeString { get; set; }
        public DateTime CreatedDateTime { get; set; }

        #region Return Obj
        public string Return_Type { get; set; } = Constants.PENDING_TYPE;
        public string? Return_Message { get; set; }
        #endregion
    }
}
