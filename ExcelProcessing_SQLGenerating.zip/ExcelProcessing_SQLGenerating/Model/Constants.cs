﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Model
{
    public static class Constants
    {
        public static readonly string tempSheetName = "TeMpOrArYsHeEt";
        public static readonly string finalSheetName = "FiNaLrEsUlTsHeEt";

        public static readonly string MSSQLDatabase = "MSSQL";
        public static readonly string OracleDatabasee = "Oracle";

        public static readonly string PENDING_TYPE = "Pending";
        public static readonly string SUCCESS_TYPE = "Success";
        public static readonly string ERROR_TYPE = "Error";
    }
}
