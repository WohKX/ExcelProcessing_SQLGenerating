﻿using C5;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static OfficeOpenXml.ExcelErrorValue;
using System.Windows.Input;

namespace ExcelProcessing_SQLGenerating.Model.DatabaseObject
{
    public class DatabaseRootObject
    {
        

        public string DBServer { get; internal set; }
        public string DBUser { get; internal set; }
        public string DBPass { get; internal set; }
        public string DBTable { get; internal set; }
        public string DBType { get;internal set; }
        public string? ConnString { get; set; }




        public string HashtableParamsPrefix { get; set; } = string.Empty;
        public string HashtableParamsSuffix { get; set; } = string.Empty;
        public string SqlParamsPrefix { get; set; } = string.Empty;
        public string SqlParamsSuffix { get; set; } = string.Empty;
        //private List<string> HashtableParams
        private const string SqlParamsReplacingSymbols = "###";




        //public string? DBServer { get; set; }
        //public string? DBServer { get; set; }
        //public string? DBServer { get; set; }

        //public string? DBServer { get; set; }


        public bool getSqlAndParams(string sql, Hashtable sqlParams, out string returnSql, out Hashtable newSqlParams)
        {
            bool successFlag = false;
            returnSql = string.Empty;
            newSqlParams = new Hashtable();
            try
            {
                foreach (DictionaryEntry dictionary in sqlParams)
                {
                    string toBeReplacedKey = string.Concat(SqlParamsReplacingSymbols, dictionary.Key);
                    string newKey = string.Concat(SqlParamsPrefix, dictionary.Key, SqlParamsSuffix);

                    newSqlParams[newKey] = dictionary.Value;
                    returnSql = sql.Replace(toBeReplacedKey, newKey);
                }
                successFlag = true;
            }
            catch
            {
                // write log here
                successFlag = false;
            }
            return successFlag;
        }


        public DatabaseRootObject(DatabaseRootObject Db)
        {
            this.DBServer = Db.DBServer;
            this.DBUser = Db.DBUser;
            this.DBPass = Db.DBPass;
            this.DBTable = Db.DBTable;

            this.HashtableParamsPrefix = Db.HashtableParamsPrefix;
            this.HashtableParamsSuffix = Db.HashtableParamsSuffix;
            this.SqlParamsPrefix = Db.SqlParamsPrefix;
            this.SqlParamsSuffix = Db.SqlParamsSuffix;
        }
    }
}
