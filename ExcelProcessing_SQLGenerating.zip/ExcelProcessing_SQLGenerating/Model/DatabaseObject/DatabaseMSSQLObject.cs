﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelProcessing_SQLGenerating.Model.DatabaseObject
{
    public class DatabaseMSSQLObject : DatabaseRootObject
    {
        public new string DBServer { get; set; }
        public new string DBUser { get; set; }
        public new string DBPass { get; set; }
        public new string DBTable { get; set; }
        public new string? ConnString { get; set; }


        public new readonly string HashtableParamsPrefix = "@";
        public new readonly string SqlParamsPrefix = "@";
        public new readonly string HashtableParamsSuffix = string.Empty;
        public new readonly string SqlParamsSuffix  = string.Empty;


        public DatabaseRootObject UnifyDatabaseRootObject()
        {
            DatabaseRootObject databaseRootObject = new (this)
            {
                ConnString = ConnString,
            };
            

            return databaseRootObject;
        }


        public DatabaseMSSQLObject(string DBServer, string DBUser, string DBPass, string DBTable) : base (new DatabaseMSSQLObject ( DBServer, DBUser, DBPass, DBTable))
        {
            this.DBServer = DBServer;
            this.DBUser = DBUser;
            this.DBPass = DBPass;
            this.DBTable = DBTable;
            this.ConnString = string.Concat("");
        }
    }
}
